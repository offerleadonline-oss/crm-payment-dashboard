import { useState, useMemo, useEffect } from 'react';
import { Search, Filter, Download, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface PaymentRecord {
  Vendedor: string | null;
  Supervisor: string | null;
  'Data Proposta': string | null;
  Contrato: string | number | null;
  CPF: string | number | null;
  CNPJ: string | number | null;
  'Cidade Lista': string | null;
  UF: string | null;
  'Forma de Pagamento': string | null;
  'DCC Banco': string | null;
  'DCC Conta': string | number | null;
  'DCC Agencia': string | number | null;
  'Netsales (forma de pagamento)': string | null;
  [key: string]: any;
}

export default function Dashboard() {
  const [data, setData] = useState<PaymentRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterPaymentMethod, setFilterPaymentMethod] = useState<string>('all');
  const [filterBank, setFilterBank] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('data');
  const [expandedRow, setExpandedRow] = useState<number | null>(null);

  // Carregar dados do JSON
  useEffect(() => {
    fetch('/data.json')
      .then((res) => res.json())
      .then((jsonData) => {
        setData(jsonData);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Erro ao carregar dados:', err);
        setLoading(false);
      });
  }, []);

  // Extrair valores únicos para filtros
  const paymentMethods = useMemo(() => {
    if (!data.length) return [];
    const methods = new Set(data.map((r: PaymentRecord) => r['Forma de Pagamento']).filter(Boolean) as string[]);
    return Array.from(methods).sort();
  }, [data]);

  const banks = useMemo(() => {
    if (!data.length) return [];
    const bankList = new Set(data.map((r: PaymentRecord) => r['DCC Banco']).filter(Boolean) as string[]);
    return Array.from(bankList).sort();
  }, [data]);

  // Filtrar e buscar dados
  const filteredData = useMemo(() => {
    let result = [...data]; // Clonar array para evitar mutação

    // Filtro de busca
    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      result = result.filter(
        (r) =>
          String(r.Vendedor || '').toLowerCase().includes(search) ||
          String(r['Cidade Lista'] || '').toLowerCase().includes(search) ||
          String(r.CPF || '').toLowerCase().includes(search) ||
          String(r.CNPJ || '').toLowerCase().includes(search) ||
          String(r.Contrato || '').includes(search)
      );
    }

    // Filtro de forma de pagamento
    if (filterPaymentMethod !== 'all') {
      result = result.filter((r) => r['Forma de Pagamento'] === filterPaymentMethod);
    }

    // Filtro de banco
    if (filterBank !== 'all') {
      result = result.filter((r) => r['DCC Banco'] === filterBank);
    }

    // Ordenação
    if (sortBy === 'data') {
      result.sort((a, b) => {
        const dateA = new Date(a['Data Proposta']?.split(' ')[0]?.split('/').reverse().join('-') || '');
        const dateB = new Date(b['Data Proposta']?.split(' ')[0]?.split('/').reverse().join('-') || '');
        return dateB.getTime() - dateA.getTime();
      });
    } else if (sortBy === 'vendedor') {
      result.sort((a, b) => (a.Vendedor || '').localeCompare(b.Vendedor || ''));
    } else if (sortBy === 'cidade') {
      result.sort((a, b) => (a['Cidade Lista'] || '').localeCompare(b['Cidade Lista'] || ''));
    }

    return result;
  }, [data, searchTerm, filterPaymentMethod, filterBank, sortBy]);

  // Função para exportar como CSV
  const handleExport = () => {
    const headers = [
      'Vendedor',
      'Supervisor',
      'Data Proposta',
      'Contrato',
      'CPF',
      'CNPJ',
      'Cidade',
      'UF',
      'Forma de Pagamento',
      'Banco',
      'Conta',
      'Agência',
    ];

    const rows = filteredData.map((r) => [
      r.Vendedor,
      r.Supervisor,
      r['Data Proposta'],
      r.Contrato,
      r.CPF,
      r.CNPJ,
      r['Cidade Lista'],
      r.UF,
      r['Forma de Pagamento'],
      r['DCC Banco'],
      r['DCC Conta'],
      r['DCC Agencia'],
    ]);

    const csv = [headers, ...rows].map((row) => row.map((cell) => `"${cell || ''}"`).join(',')).join('\n');

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `formas-pagamento-${new Date().toISOString().split('T')[0]}.csv`);
    link.click();
  };

  const getPaymentBadgeColor = (method: string | null) => {
    if (method === 'BOLETO') return 'bg-blue-100 text-blue-800';
    if (method === 'DCC') return 'bg-green-100 text-green-800';
    return 'bg-gray-100 text-gray-800';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando dados...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Formas de Pagamento</h1>
                <p className="text-gray-600 mt-1">Dashboard de vendas e transações - NetX CRM</p>
              </div>
              <Button
                onClick={handleExport}
                variant="outline"
                className="gap-2 hidden sm:flex"
              >
                <Download className="w-4 h-4" />
                Exportar CSV
              </Button>
            </div>

            {/* Controles de Filtro */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {/* Busca */}
              <div className="relative lg:col-span-2">
                <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Buscar por vendedor, cidade, CPF..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-white"
                />
              </div>

              {/* Forma de Pagamento */}
              <Select value={filterPaymentMethod} onValueChange={setFilterPaymentMethod}>
                <SelectTrigger className="bg-white">
                  <SelectValue placeholder="Forma de Pagamento" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas as Formas</SelectItem>
                  {paymentMethods.map((method: string) => (
                    <SelectItem key={method} value={method}>
                      {method}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Banco */}
              <Select value={filterBank} onValueChange={setFilterBank}>
                <SelectTrigger className="bg-white">
                  <SelectValue placeholder="Banco" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os Bancos</SelectItem>
                  {banks.map((bank: string) => (
                    <SelectItem key={bank} value={bank}>
                      {bank}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Ordenação e Resultados */}
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-600">
                <span className="font-semibold text-gray-900">{filteredData.length}</span> registros
              </div>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-auto bg-white">
                  <SelectValue placeholder="Ordenar por" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="data">Data (Mais Recente)</SelectItem>
                  <SelectItem value="vendedor">Vendedor (A-Z)</SelectItem>
                  <SelectItem value="cidade">Cidade (A-Z)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </div>

      {/* Conteúdo Principal */}
      <div className="container mx-auto px-4 py-8">
        {filteredData.length === 0 ? (
          <div className="text-center py-12">
            <Filter className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-600 text-lg">Nenhum registro encontrado</p>
            <p className="text-gray-500 text-sm">Tente ajustar seus filtros</p>
          </div>
        ) : (
          <>
            {/* Tabela Desktop */}
            <div className="hidden lg:block bg-white rounded-lg border border-gray-200 overflow-hidden shadow-sm">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                        Vendedor
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                        Data
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                        Cliente
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                        Cidade
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                        Forma de Pagamento
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                        Banco
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                        Contrato
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {filteredData.map((record, idx) => (
                      <tr
                        key={idx}
                        className="hover:bg-blue-50 transition-colors cursor-pointer"
                        onClick={() => setExpandedRow(expandedRow === idx ? null : idx)}
                      >
                        <td className="px-6 py-4 text-sm font-medium text-gray-900">
                          {record.Vendedor}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-600">
                          {record['Data Proposta']?.split(' ')[0] || '-'}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-600">
                          <div className="truncate max-w-xs" title={String(record.CPF || record.CNPJ || '')}>
                            {record.CPF || record.CNPJ || '-'}
                          </div>
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-600">
                          {record['Cidade Lista']} - {record.UF}
                        </td>
                        <td className="px-6 py-4 text-sm">
                          <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${getPaymentBadgeColor(record['Forma de Pagamento'])}`}>
                            {record['Forma de Pagamento']}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-600">
                          {record['DCC Banco'] || '-'}
                        </td>
                        <td className="px-6 py-4 text-sm font-mono text-gray-600">
                          {record.Contrato}
                        </td>
                        <td className="px-6 py-4"></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Cards Mobile */}
            <div className="lg:hidden grid grid-cols-1 gap-4">
              {filteredData.map((record, idx) => (
                <div
                  key={idx}
                  className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden hover:shadow-md transition-shadow"
                >
                  <div
                    className="p-4 cursor-pointer"
                    onClick={() => setExpandedRow(expandedRow === idx ? null : idx)}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-gray-900 truncate">
                          {record.Vendedor}
                        </h3>
                        <p className="text-sm text-gray-600 mt-1">
                          {record['Cidade Lista']} - {record.UF}
                        </p>
                        <div className="flex items-center gap-2 mt-2 flex-wrap">
                          <span className={`inline-block px-2 py-1 rounded text-xs font-semibold ${getPaymentBadgeColor(record['Forma de Pagamento'])}`}>
                            {record['Forma de Pagamento']}
                          </span>
                          {record['DCC Banco'] && (
                            <span className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded">
                              {record['DCC Banco']}
                            </span>
                          )}
                        </div>
                      </div>
                      <ChevronDown
                        className={`w-5 h-5 text-gray-400 flex-shrink-0 transition-transform ${
                          expandedRow === idx ? 'rotate-180' : ''
                        }`}
                      />
                    </div>
                  </div>

                  {/* Detalhes Expandidos */}
                  {expandedRow === idx && (
                    <div className="border-t border-gray-200 px-4 py-3 bg-gray-50 text-sm space-y-2">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <p className="text-xs font-semibold text-gray-600 uppercase">Data</p>
                          <p className="text-gray-900">{record['Data Proposta']}</p>
                        </div>
                        <div>
                          <p className="text-xs font-semibold text-gray-600 uppercase">Contrato</p>
                          <p className="font-mono text-gray-900">{record.Contrato}</p>
                        </div>
                        <div>
                          <p className="text-xs font-semibold text-gray-600 uppercase">CPF/CNPJ</p>
                          <p className="font-mono text-gray-900 text-xs">{record.CPF || record.CNPJ || '-'}</p>
                        </div>
                        <div>
                          <p className="text-xs font-semibold text-gray-600 uppercase">Supervisor</p>
                          <p className="text-gray-900 text-xs">{record.Supervisor}</p>
                        </div>
                        {record['DCC Banco'] && (
                          <>
                            <div>
                              <p className="text-xs font-semibold text-gray-600 uppercase">Banco</p>
                              <p className="text-gray-900">{record['DCC Banco']}</p>
                            </div>
                            <div>
                              <p className="text-xs font-semibold text-gray-600 uppercase">Agência</p>
                              <p className="font-mono text-gray-900">{record['DCC Agencia']}</p>
                            </div>
                            <div className="col-span-2">
                              <p className="text-xs font-semibold text-gray-600 uppercase">Conta</p>
                              <p className="font-mono text-gray-900">{record['DCC Conta']}</p>
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Footer com Estatísticas */}
      <div className="bg-white border-t border-gray-200 mt-12">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-blue-600">
                {filteredData.length}
              </p>
              <p className="text-sm text-gray-600 mt-1">Total de Registros</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-green-600">
                {filteredData.filter((r) => r['Forma de Pagamento'] === 'BOLETO').length}
              </p>
              <p className="text-sm text-gray-600 mt-1">Boletos</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-purple-600">
                {filteredData.filter((r) => r['Forma de Pagamento'] === 'DCC').length}
              </p>
              <p className="text-sm text-gray-600 mt-1">DCCs</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-orange-600">
                {new Set(filteredData.map((r) => r.Vendedor)).size}
              </p>
              <p className="text-sm text-gray-600 mt-1">Vendedores</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
